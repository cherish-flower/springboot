package net.xdclass.online_xdclass.service;

import net.xdclass.online_xdclass.domain.Video;

import java.util.List;

public interface VideoService {

    List<Video> listVideo();
}
