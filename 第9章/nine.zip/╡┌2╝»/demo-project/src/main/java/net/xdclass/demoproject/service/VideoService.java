package net.xdclass.demoproject.service;

import net.xdclass.demoproject.domain.Video;

import java.util.List;

public interface VideoService {

    List<Video> listVideo();

}
