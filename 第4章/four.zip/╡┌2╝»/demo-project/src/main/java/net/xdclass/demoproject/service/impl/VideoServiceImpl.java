package net.xdclass.demoproject.service.impl;

import net.xdclass.demoproject.service.VideoService;

public class VideoServiceImpl implements VideoService {


}
