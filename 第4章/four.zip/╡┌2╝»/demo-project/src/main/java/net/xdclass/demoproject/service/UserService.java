package net.xdclass.demoproject.service;

public interface UserService {
}
