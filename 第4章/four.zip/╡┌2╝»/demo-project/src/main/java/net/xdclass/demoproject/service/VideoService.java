package net.xdclass.demoproject.service;

public interface VideoService {
}
