package net.xdclass.demoproject.service.impl;

import net.xdclass.demoproject.service.UserService;

public class UserServiceImpl implements UserService {

}
