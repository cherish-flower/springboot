package net.xdclass.demoproject.service;

public interface UserService {

    String login(String username, String pwd);
}
