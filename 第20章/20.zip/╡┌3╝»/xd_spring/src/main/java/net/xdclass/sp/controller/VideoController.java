package net.xdclass.sp.controller;

public class VideoController {
}
