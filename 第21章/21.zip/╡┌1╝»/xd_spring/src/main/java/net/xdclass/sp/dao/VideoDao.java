package net.xdclass.sp.dao;

public class VideoDao {
}
