package net.xdclass.sp.service;

public class VideoService {
}
