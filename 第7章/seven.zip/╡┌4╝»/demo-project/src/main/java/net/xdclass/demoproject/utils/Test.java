package net.xdclass.demoproject.utils;

public class Test {
    public static void main(String[] args) {
        int a = 1;
        Integer b = 1;
        add(a, b);
        System.out.println(a);
        System.out.println(b);
    }

    private static void add(int a, Integer b) {
        a = a + 1;
        b = b + 1;
    }
}
